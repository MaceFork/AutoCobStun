package com.example.webstun;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Auto Web Stun with camera aim. Fabric, Minecraft 1.21.11 (Yarn).
 * Idea credit: TikTok @hyper2up "How to web stun".
 *
 * For singleplayer / your own server / practice worlds only. The mod does
 * nothing on other servers (see ALLOWED_HOSTS).
 *
 * Trigger: you hit a player. Then, automatically:
 *   1. swap to axe, hit (breaks a raised shield)
 *   2. look down at their feet, swap to cobweb
 *   3. place the cobweb at their feet
 *   4. look back at their chest, swap back to your old slot
 * Needs BOTH an axe and cobweb in the hotbar.
 */
public class WebStunClient implements ClientModInitializer {
    /** Add your own server address here if you host one (e.g. "play.myserver.net"). */
    private static final List<String> ALLOWED_HOSTS = List.of("localhost", "127.0.0.1");
    /** true = only fire when the target is holding up a shield. */
    private static final boolean ONLY_VS_SHIELD = false;
    private static final double REACH_SQ = 4.5 * 4.5;

    private int step = 0, wait = 0, cooldown = 0;
    private PlayerEntity target;
    private int origSlot, axeSlot, webSlot;

    @Override
    public void onInitializeClient() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && step == 0 && cooldown == 0 && allowedHere(mc)
                    && player == mc.player && entity instanceof PlayerEntity t) {
                int ax = find(mc.player, true), wb = find(mc.player, false);
                if (ax >= 0 && wb >= 0 && (!ONLY_VS_SHIELD || t.isBlocking())) {
                    target = t; axeSlot = ax; webSlot = wb;
                    origSlot = mc.player.getInventory().getSelectedSlot();
                    wait = 0;
                    // already holding the axe? that hit was the shield breaker
                    step = mc.player.getMainHandStack().getItem() instanceof AxeItem ? 3 : 1;
                }
            }
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cooldown > 0) cooldown--;
        if (p == null || mc.interactionManager == null) { step = 0; return; }
        if (step == 0) return;

        if (!target.isAlive() || p.squaredDistanceTo(target) > REACH_SQ) { finish(p); return; }

        switch (step) {
            case 1 -> { p.getInventory().setSelectedSlot(axeSlot); step = 2; }
            case 2 -> {
                // wait for the axe's cooldown so the hit can break the shield
                if (p.getAttackCooldownProgress(0f) >= 0.9f || ++wait > 30) {
                    mc.interactionManager.attackEntity(p, target);
                    p.swingHand(Hand.MAIN_HAND);
                    step = 3;
                }
            }
            case 3 -> {                         // look down at their feet
                lookAt(p, new Vec3d(target.getX(), target.getY(), target.getZ()));
                p.getInventory().setSelectedSlot(webSlot);
                step = 4;
            }
            case 4 -> {                         // place web at their feet
                lookAt(p, new Vec3d(target.getX(), target.getY(), target.getZ()));
                BlockPos feet = target.getBlockPos();
                Vec3d pos = new Vec3d(feet.getX() + 0.5, feet.getY(), feet.getZ() + 0.5);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                        new BlockHitResult(pos, Direction.UP, feet.down(), false));
                p.swingHand(Hand.MAIN_HAND);
                step = 5;
            }
            case 5 -> {                         // look back at their chest
                lookAt(p, new Vec3d(target.getX(), target.getY() + target.getHeight() * 0.7, target.getZ()));
                finish(p);
            }
        }
    }

    private void finish(ClientPlayerEntity p) {
        p.getInventory().setSelectedSlot(origSlot);
        step = 0;
        cooldown = 20;
    }

    private static void lookAt(ClientPlayerEntity p, Vec3d point) {
        Vec3d d = point.subtract(p.getEyePos());
        double flat = Math.sqrt(d.x * d.x + d.z * d.z);
        p.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        p.setPitch((float) -Math.toDegrees(Math.atan2(d.y, flat)));
    }

    private static boolean allowedHere(MinecraftClient mc) {
        if (mc.isInSingleplayer()) return true;
        var entry = mc.getCurrentServerEntry();
        if (entry == null) return false;
        String host = entry.address.toLowerCase().split(":")[0];
        return ALLOWED_HOSTS.contains(host);
    }

    private static int find(ClientPlayerEntity p, boolean axe) {
        for (int i = 0; i < 9; i++) {
            var item = p.getInventory().getStack(i).getItem();
            if (axe ? item instanceof AxeItem : item == Items.COBWEB) return i;
        }
        return -1;
    }
}
